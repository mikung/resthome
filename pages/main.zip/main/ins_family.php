<?php
/**
 * Created by PhpStorm.
 * User: teerawatjordee
 * Date: 29/8/2018 AD
 * Time: 22:00
 */
include "../../lip/pdomysqlresthome.php";
$pid = $_POST['pid'];
$fname = $_POST['fname'];
$fs = $_POST['fs'];
$fw = $_POST['fw'];
//print_r( $_POST);
//exit();
$mysql = new pdomysqlresthome();
$sql = "insert into memfamily (ID_Personnal,memf_name,relationf_id,id_department) values ('$pid','$fname','$fs','$fw') ";
//$sql = 'insert into memfamily (ID_Personnal) values ("2") ';
$query = $mysql->insertData($sql);

echo $query;