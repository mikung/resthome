<?php
extract($_POST);
echo "remark=$remark"

?>
<!--script>
    window.location ='../main/indexuser.php';
    window.open ='../main/printformborrow.php','_blank';
</script-->
